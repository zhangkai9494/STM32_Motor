#ifndef __PRINTF_H_
#define __PRINTF_H_

void Printf(char* data, ...);

#endif