#ifndef _KEY_H_
#define _KEY_H_

int GetKey(void);
void KEY_Init(void);
	
#endif

