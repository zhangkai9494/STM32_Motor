#ifndef __PID_H_
#define __PID_H_

#include "sys.h"


void PID_init(float Kp,float Ki,float Kd,u16 skap);//PID��ʼ������
int PID_realize(float speed,float ActualSpeed);



#endif
